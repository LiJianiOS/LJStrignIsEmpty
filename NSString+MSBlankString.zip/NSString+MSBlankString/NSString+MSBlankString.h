//
//  NSString+MSBlankString.h
//  lvpai
//
//  Created by MaShuai on 16/5/14.
//  Copyright © 2016年 司马帅帅. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (MSBlankString)

//判断一个字符串是否为空
+ (BOOL)isBlankString:(NSString *)string;

@end
